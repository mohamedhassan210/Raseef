﻿using Rassef.Filters;
using Rassef.ViewModels.Administration;
using Rassef.ViewModels.Administration.Employee;
namespace Rassef.Controllers
{
    [PermissionAuthorize]
    public class AdministrationController : Controller
    {
        private readonly ISupplierRequestRepository _supplierRequestRepository;
        private readonly ITransferRequestRepository _Transferrepository;
        private readonly IUserRepository _userRepository;
        private readonly IRepository<Position> _positionRepository;
        private readonly IRepository<UserGroup> _groupRepository;
        private readonly IRepository<Truck> _truckRepository;
        private readonly IRepository<TruckTypes> _truckTypesRepository;
        private readonly IRepository<Driver> _driverRepository;
        private readonly IRepository<DriverTypes> _driverTypeRepository;
        private readonly IRepository<Supplier> _supplierRepository;
        private readonly ITicketEngineService _ticketEngineService;
        private readonly IRepository<Warehouse> _warehouseRepository;           // NEW
        private readonly IRepository<UserWarehouse> _userWarehouseRepository;   // NEW

        public AdministrationController(
            IUserRepository userRepository,
            IRepository<Position> positionRepository,
            IRepository<UserGroup> groupRepository,
            IRepository<Truck> truckRepository,
            IRepository<TruckTypes> truckTypeRepository,
            IRepository<Driver> driverRepository,
            IRepository<DriverTypes> driverTypeRepository,
            ITransferRequestRepository transferRequestRepository,
            ISupplierRequestRepository supplierRequestRepository,
            IRepository<Supplier> supplierRepository,
            ITicketEngineService ticketEngineService,
            IRepository<Warehouse> warehouseRepository,           // NEW
            IRepository<UserWarehouse> userWarehouseRepository)   // NEW
        {
            _userRepository = userRepository;
            _positionRepository = positionRepository;
            _groupRepository = groupRepository;
            _truckRepository = truckRepository;
            _truckTypesRepository = truckTypeRepository;
            _driverRepository = driverRepository;
            _driverTypeRepository = driverTypeRepository;
            _Transferrepository = transferRequestRepository;
            _supplierRequestRepository = supplierRequestRepository;
            _supplierRepository = supplierRepository;
            _ticketEngineService = ticketEngineService;
            _warehouseRepository = warehouseRepository;             // NEW
            _userWarehouseRepository = userWarehouseRepository;     // NEW
        }

        //Employee Administration
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var users = await _userRepository.GetAllAsync(query =>
                query.Where(u => !u.IsDeleted).Include(u => u.Position).Include(u => u.Group)
            );

            var employees = users.Select(u => new EmployeeListVM
            {
                Id = u.Id,
                Name = u.Name,
                Phone = u.Phone,
                Email = u.Email?.ToString() ?? string.Empty,
                Role = u.Position?.PositionName ?? "غير محدد",
                GroupName = u.Group?.Name ?? "غير محدد",
                NationalId = u.NationalId,
                UserCode = u.UserCode ?? string.Empty
            }).ToList();

            if (!employees.Any())
            {
                ModelState.AddModelError(
                    string.Empty,
                    "لا يوجد أي موظفين حتى الآن."
                );
            }

            return View(employees);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var users = await _userRepository.GetAllAsync(query =>
                query.Include(u => u.Position).Include(u => u.Group)
            );

            var user = users.FirstOrDefault(u => u.Id == id && !u.IsDeleted);

            if (user == null)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذا الموظف غير موجود."
                );

                return RedirectToAction(nameof(Index));
            }

            // NEW — the warehouses this employee can access, same source the edit form
            // writes to, so details and edit can never disagree.
            var warehouseLinks = await _userWarehouseRepository.GetAllAsync(q => q
                .Where(uw => uw.UserId == user.Id && !uw.IsDeleted)
                .Include(uw => uw.Warehouse));

            var accessibleWarehouses = warehouseLinks
                .Where(uw => uw.Warehouse != null && !uw.Warehouse.IsDeleted)
                .Select(uw => uw.Warehouse.Name)
                .OrderBy(name => name)
                .ToList();

            var employee = new EmployeeDetailsVM
            {
                AccessibleWarehouses = accessibleWarehouses,
                Id = user.Id,
                Name = user.Name,
                UserName = user.UserName ?? string.Empty,
                UserCode = user.UserCode ?? string.Empty,
                BranchCode = user.BranchCode ?? string.Empty,
                Role = user.Position?.PositionName ?? "غير محدد",
                GroupName = user.Group?.Name ?? "غير محدد",
                Phone = user.Phone,
                Email = user.Email?.ToString() ?? string.Empty,
                NationalId = user.NationalId
            };

            return View(employee);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var positions = await _positionRepository.GetAllAsync(q => q.Where(p => !p.IsDeleted));
            var groups = await _groupRepository.GetAllAsync(q => q.Where(g => !g.IsDeleted));
            var warehouses = await _warehouseRepository.GetAllAsync(q => q.Where(w => !w.IsDeleted)); // NEW

            ViewBag.Positions = positions;
            ViewBag.Groups = groups;
            ViewBag.Warehouses = warehouses; // NEW

            return View(new EmployeeCreateVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EmployeeCreateVM model)
        {
            if (string.IsNullOrWhiteSpace(model.Phone) || !System.Text.RegularExpressions.Regex.IsMatch(model.Phone.Trim(), @"^01[0125][0-9]{8}$"))
            {
                ModelState.AddModelError(nameof(model.Phone), "رقم الهاتف يجب أن يكون رقم مصري صحيح مكون من 11 رقماً (يبدأ بـ 010 أو 011 أو 012 أو 015).");
            }

            if (string.IsNullOrWhiteSpace(model.NationalId) || !System.Text.RegularExpressions.Regex.IsMatch(model.NationalId.Trim(), @"^[0-9]{14}$"))
            {
                ModelState.AddModelError(nameof(model.NationalId), "الرقم القومي يجب أن يتكون من 14 رقماً بالضبط.");
            }

            var existingUser = await _userRepository.FindAsync(u => u.NationalId == model.NationalId && !u.IsDeleted);
            if (existingUser != null)
            {
                ModelState.AddModelError(nameof(model.NationalId), "الرقم القومي مُسجل لموظف آخر بالفعل.");
            }

            var existingUserPhone = await _userRepository.FindAsync(u => u.Phone == model.Phone && !u.IsDeleted);
            if (existingUserPhone != null)
            {
                ModelState.AddModelError(nameof(model.Phone), "رقم الهاتف مُسجل لموظف آخر بالفعل.");
            }

            if (model.GroupId <= 0)
            {
                ModelState.AddModelError(nameof(model.GroupId), "يرجى اختيار مجموعة الصلاحيات للموظف.");
            }

            if (model.PositionId <= 0)
            {
                ModelState.AddModelError(nameof(model.PositionId), "يرجى اختيار الدور الوظيفي للموظف.");
            }

            if (!string.IsNullOrWhiteSpace(model.UserName))
            {
                var existingUserName = await _userRepository.FindAsync(u => u.UserName == model.UserName && !u.IsDeleted);
                if (existingUserName != null)
                {
                    ModelState.AddModelError(nameof(model.UserName), "اسم المستخدم مُسجل لموظف آخر بالفعل.");
                }
            }

            if (!ModelState.IsValid)
            {
                var positions = await _positionRepository.GetAllAsync(q => q.Where(p => !p.IsDeleted));
                var groups = await _groupRepository.GetAllAsync(q => q.Where(g => !g.IsDeleted));
                var warehouses = await _warehouseRepository.GetAllAsync(q => q.Where(w => !w.IsDeleted)); // NEW

                ViewBag.Positions = positions;
                ViewBag.Groups = groups;
                ViewBag.Warehouses = warehouses; // NEW

                return View(model);
            }

            var user = new User
            {
                Name = model.Name,
                UserName = model.UserName,
                Phone = model.Phone.Trim(),
                Email = Email.Create(model.Email),
                PositionId = model.PositionId,
                GroupId = model.GroupId,
                NationalId = model.NationalId.Trim(),
                UserCode = model.UserCode,
                BranchCode = model.BranchCode ?? string.Empty,
                HashPassword = BCrypt.Net.BCrypt.HashPassword(model.UserCode)
            };

            await _userRepository.AddAsync(user);
            await _userRepository.SaveChangesAsync();

            // NEW — link the employee to whichever warehouses were checked. Never trust
            // posted ids blindly: only link ids that are real, active warehouses.
            if (model.SelectedWarehouseIds != null && model.SelectedWarehouseIds.Any())
            {
                var validWarehouseIds = (await _warehouseRepository.GetAllAsync(q => q.Where(w => !w.IsDeleted)))
                    .Select(w => w.Id)
                    .ToHashSet();

                foreach (var warehouseId in model.SelectedWarehouseIds.Distinct())
                {
                    if (!validWarehouseIds.Contains(warehouseId)) continue;

                    await _userWarehouseRepository.AddAsync(new UserWarehouse
                    {
                        UserId = user.Id,
                        WarehouseId = warehouseId
                    });
                }

                await _userWarehouseRepository.SaveChangesAsync();
            }

            TempData["Success"] = "تم إضافة الموظف بنجاح.";
            return RedirectToAction(nameof(Index));
        }
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var users = await _userRepository.GetAllAsync(query =>
                query.Include(u => u.Position).Include(u => u.Group)
            );

            var user = users.FirstOrDefault(u => u.Id == id && !u.IsDeleted);

            if (user == null)
            {
                ModelState.AddModelError(string.Empty, "هذا الموظف غير موجود.");
                return RedirectToAction(nameof(Index));
            }

            var positions = await _positionRepository.GetAllAsync(q => q.Where(p => !p.IsDeleted));
            var groups = await _groupRepository.GetAllAsync(q => q.Where(g => !g.IsDeleted));
            var warehouses = await _warehouseRepository.GetAllAsync(q => q.Where(w => !w.IsDeleted)); // NEW

            // NEW — this employee's current warehouse links, to pre-check the boxes.
            var userWarehouses = await _userWarehouseRepository.GetAllAsync(q =>
                q.Where(uw => uw.UserId == user.Id && !uw.IsDeleted));
            var selectedWarehouseIds = userWarehouses.Select(uw => uw.WarehouseId).ToList();

            ViewBag.Positions = positions;
            ViewBag.Groups = groups;
            ViewBag.Warehouses = warehouses; // NEW

            var employee = new EmployeeEditVM
            {
                Id = user.Id,
                Name = user.Name,
                UserName = user.UserName ?? string.Empty,
                Phone = user.Phone,
                Email = user.Email?.ToString() ?? string.Empty,
                PositionId = user.PositionId,
                GroupId = user.GroupId ?? 0,
                NationalId = user.NationalId,
                UserCode = user.UserCode ?? string.Empty,
                BranchCode = user.BranchCode ?? string.Empty,
                SelectedWarehouseIds = selectedWarehouseIds // NEW
            };

            return View(employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EmployeeEditVM model)
        {
            if (string.IsNullOrWhiteSpace(model.Phone) || !System.Text.RegularExpressions.Regex.IsMatch(model.Phone.Trim(), @"^01[0125][0-9]{8}$"))
            {
                ModelState.AddModelError(nameof(model.Phone), "رقم الهاتف يجب أن يكون رقم مصري صحيح مكون من 11 رقماً (يبدأ بـ 010 أو 011 أو 012 أو 015).");
            }

            if (string.IsNullOrWhiteSpace(model.NationalId) || !System.Text.RegularExpressions.Regex.IsMatch(model.NationalId.Trim(), @"^[0-9]{14}$"))
            {
                ModelState.AddModelError(nameof(model.NationalId), "الرقم القومي يجب أن يتكون من 14 رقماً بالضبط.");
            }

            var existingUser = await _userRepository.FindAsync(u => u.NationalId == model.NationalId && u.Id != model.Id && !u.IsDeleted);
            if (existingUser != null)
            {
                ModelState.AddModelError(nameof(model.NationalId), "الرقم القومي مُسجل لموظف آخر بالفعل.");
            }

            var existingUserPhone = await _userRepository.FindAsync(u => u.Phone == model.Phone && u.Id != model.Id && !u.IsDeleted);
            if (existingUserPhone != null)
            {
                ModelState.AddModelError(nameof(model.Phone), "رقم الهاتف مُسجل لموظف آخر بالفعل.");
            }

            if (model.GroupId <= 0)
            {
                ModelState.AddModelError(nameof(model.GroupId), "يرجى اختيار مجموعة الصلاحيات للموظف.");
            }

            if (model.PositionId <= 0)
            {
                ModelState.AddModelError(nameof(model.PositionId), "يرجى اختيار الدور الوظيفي للموظف.");
            }

            if (!string.IsNullOrWhiteSpace(model.UserName))
            {
                var existingUserName = await _userRepository.FindAsync(u => u.UserName == model.UserName && u.Id != model.Id && !u.IsDeleted);
                if (existingUserName != null)
                {
                    ModelState.AddModelError(nameof(model.UserName), "اسم المستخدم مُسجل لموظف آخر بالفعل.");
                }
            }

            if (!ModelState.IsValid)
            {
                var positions = await _positionRepository.GetAllAsync(q => q.Where(p => !p.IsDeleted));
                var groups = await _groupRepository.GetAllAsync(q => q.Where(g => !g.IsDeleted));
                var warehouses = await _warehouseRepository.GetAllAsync(q => q.Where(w => !w.IsDeleted)); // NEW

                ViewBag.Positions = positions;
                ViewBag.Groups = groups;
                ViewBag.Warehouses = warehouses; // NEW

                return View(model);
            }

            var user = await _userRepository.GetByIdAsync(model.Id);

            if (user == null || user.IsDeleted)
            {
                ModelState.AddModelError(string.Empty, "هذا الموظف غير موجود.");

                // Without this the view falls back to empty lists, so the position,
                // group and warehouse controls would all render blank on this path.
                ViewBag.Positions = await _positionRepository.GetAllAsync(q => q.Where(p => !p.IsDeleted));
                ViewBag.Groups = await _groupRepository.GetAllAsync(q => q.Where(g => !g.IsDeleted));
                ViewBag.Warehouses = await _warehouseRepository.GetAllAsync(q => q.Where(w => !w.IsDeleted));

                return View(model);
            }

            user.Name = model.Name;
            user.UserName = model.UserName;
            user.Phone = model.Phone.Trim();
            user.Email = Email.Create(model.Email);
            user.PositionId = model.PositionId;
            user.GroupId = model.GroupId;
            user.NationalId = model.NationalId.Trim();
            user.UserCode = model.UserCode;
            user.BranchCode = model.BranchCode ?? string.Empty;
            user.MarkAsUpdated();

            _userRepository.Update(user);
            await _userRepository.SaveChangesAsync();

            // NEW — sync this employee's warehouse links to match the checked boxes:
            // soft-delete links that got unchecked, add links that are newly checked.
            var validWarehouseIds = (await _warehouseRepository.GetAllAsync(q => q.Where(w => !w.IsDeleted)))
                .Select(w => w.Id)
                .ToHashSet();
            var selectedIds = (model.SelectedWarehouseIds ?? new List<int>())
                .Where(validWarehouseIds.Contains)
                .Distinct()
                .ToHashSet();

            var existingLinks = await _userWarehouseRepository.GetAllAsync(q =>
                q.Where(uw => uw.UserId == user.Id && !uw.IsDeleted));

            foreach (var link in existingLinks.Where(l => !selectedIds.Contains(l.WarehouseId)))
            {
                link.IsDeleted = true;
                _userWarehouseRepository.Update(link);
            }

            var existingWarehouseIds = existingLinks.Select(l => l.WarehouseId).ToHashSet();
            foreach (var warehouseId in selectedIds.Where(id => !existingWarehouseIds.Contains(id)))
            {
                await _userWarehouseRepository.AddAsync(new UserWarehouse
                {
                    UserId = user.Id,
                    WarehouseId = warehouseId
                });
            }

            await _userWarehouseRepository.SaveChangesAsync();

            TempData["Success"] = "تم تعديل بيانات الموظف بنجاح.";
            return RedirectToAction(nameof(Index));
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var users = await _userRepository.GetAllAsync(query =>
                query.Include(u => u.Position)
            );

            var user = users.FirstOrDefault(u => u.Id == id && !u.IsDeleted);

            if (user == null)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذا الموظف غير موجود."
                );

                return RedirectToAction(nameof(Index));
            }

            var employee = new EmployeeDeleteVM
            {
                Id = user.Id,
                Name = user.Name,
                UserCode = user.UserCode ?? string.Empty,
                Role = user.Position?.PositionName ?? "غير محدد",
                Phone = user.Phone,
                Email = user.Email?.ToString() ?? string.Empty,
                NationalId = user.NationalId
            };

            return View(employee);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);

            if (user == null || user.IsDeleted)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذا الموظف غير موجود."
                );

                return RedirectToAction(nameof(Index));
            }

            user.IsDeleted = true;
            user.MarkAsUpdated();

            _userRepository.Update(user);
            await _userRepository.SaveChangesAsync();

            TempData["Success"] = "تم حذف الموظف بنجاح.";

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> ChangePassword(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);

            if (user == null || user.IsDeleted)
            {
                ModelState.AddModelError(string.Empty, "هذا الموظف غير موجود.");
                return RedirectToAction(nameof(Index));
            }

            var model = new ChangePasswordVM
            {
                Id = user.Id,
                EmployeeName = user.Name
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordVM model)
        {
            if (string.IsNullOrEmpty(model.NewPassword))
            {
                ModelState.AddModelError(nameof(model.NewPassword), "يرجى إدخال كلمة المرور الجديدة.");
            }
            else if (model.NewPassword != model.ConfirmPassword)
            {
                ModelState.AddModelError(nameof(model.ConfirmPassword), "كلمتا المرور غير متطابقتين.");
            }

            if (!ModelState.IsValid)
            {
                // Repopulate the name for display — it isn't posted back from the form fields.
                var existing = await _userRepository.GetByIdAsync(model.Id);
                model.EmployeeName = existing?.Name ?? model.EmployeeName;
                return View(model);
            }

            var user = await _userRepository.GetByIdAsync(model.Id);

            if (user == null || user.IsDeleted)
            {
                ModelState.AddModelError(string.Empty, "هذا الموظف غير موجود.");
                return View(model);
            }

            user.HashPassword = BCrypt.Net.BCrypt.HashPassword(model.NewPassword);
            user.MarkAsUpdated();

            _userRepository.Update(user);
            await _userRepository.SaveChangesAsync();

            TempData["Success"] = "تم تغيير كلمة المرور بنجاح.";

            return RedirectToAction(nameof(Details), new { id = model.Id });
        }


        ////////////////////
        ////////////////////

        //Truck Administration

        /// <summary>
        /// Shared company/context display for a truck, used by both TrucksIndex and
        /// TruckDetails. CHANGED — TruckDetails previously used truck.TruckType?.Name
        /// as "Company", which is a different (and wrong) value from what Index shows
        /// for the same truck. Both now use this one computation.
        /// </summary>
        // GetTruckCompanyDisplay removed entirely — no longer needed.

        [HttpGet]
        public async Task<IActionResult> TrucksIndex()
        {
            var trucks = await _truckRepository.GetAllAsync(query =>
                query.Where(t => !t.IsDeleted)
                     .Include(t => t.CreatedBy)
                     .Include(t => t.TruckType)
            );
            // CHANGED — SupplierRequests/TransferRequests includes dropped: they were only
            // ever used to feed GetTruckCompanyDisplay, which is gone.

            var truckList = trucks.Select(t => new ViewModels.Administration.TruckListVM
            {
                Id = t.Id,
                PlateNumber = $"{t.PlateLetter} {t.PlateNumber}",
                IsRefrigerated = t.IsRefrigerated ? "تبريد" : "لا تبريد",
                // CHANGED — Company (fabricated) replaced with the truck's real TruckType relation.
                TruckTypeName = t.TruckType?.Name ?? "غير محدد",
                StorageCapacity = t.StorageCapacity,
                HostEmployeeName = !string.IsNullOrWhiteSpace(t.CreatedBy?.Name) ? t.CreatedBy.Name : (!string.IsNullOrWhiteSpace(t.CreatedBy?.UserName) ? t.CreatedBy.UserName : "المسؤول")
            }).ToList();

            if (!truckList.Any())
            {
                ModelState.AddModelError(string.Empty, "لا يوجد أي شاحنات مسجلة حتى الآن.");
            }

            return View(truckList);
        }

        [HttpGet]
        public async Task<IActionResult> TruckDetails(int id)
        {
            var trucks = await _truckRepository.GetAllAsync(query =>
                query.Where(t => !t.IsDeleted)
                     .Include(t => t.CreatedBy)
                     .Include(t => t.TruckType)
                     .Include(t => t.SupplierRequests)
                     .Include(t => t.TransferRequests)
            );
            // NOTE — SupplierRequests/TransferRequests includes kept here only because
            // VisitsCount still legitimately needs the counts. If VisitsCount goes away too,
            // these can drop as well.

            var truck = trucks.FirstOrDefault(t => t.Id == id);

            if (truck == null)
            {
                ModelState.AddModelError(string.Empty, "هذه الشاحنة غير موجودة.");
                return RedirectToAction(nameof(TrucksIndex));
            }

            int visitsCount = (truck.SupplierRequests?.Count ?? 0) + (truck.TransferRequests?.Count ?? 0);

            var truckDetails = new ViewModels.Administration.Truck.TruckDetailsVM
            {
                Id = truck.Id,
                VisitsCount = visitsCount,
                PlateNumber = $"{truck.PlateLetter} {truck.PlateNumber}",
                IsRefrigerated = truck.IsRefrigerated ? "تبريد" : "لا تبريد",
                // CHANGED — Company (fabricated) replaced with the truck's real TruckType relation.
                TruckTypeName = truck.TruckType?.Name ?? "غير محدد",
                StorageCapacity = truck.StorageCapacity,
                HostEmployeeName = truck.CreatedBy?.Name ?? "غير محدد"
            };

            return View(truckDetails);
        }

        [HttpGet]
        public async Task<IActionResult> TruckCreate()
        {
            var truckTypes = await _truckTypesRepository.GetAllAsync();
            ViewBag.TruckTypes = truckTypes;

            return View(new TruckCreateVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TruckCreate(TruckCreateVM model)
        {
            if (!ModelState.IsValid)
            {
                var truckTypes = await _truckTypesRepository.GetAllAsync();
                ViewBag.TruckTypes = truckTypes;

                return View(model);
            }

            // التحقق من عدم تكرار رقم وحروف اللوحة معاً
            var plateNum = model.PlateNumber?.Trim() ?? "";
            var plateLet = model.PlateLetter?.Trim() ?? "";

            if (await _truckRepository.ExistsAsync(x => x.PlateNumber == plateNum && x.PlateLetter == plateLet && !x.IsDeleted))
            {
                ModelState.AddModelError(nameof(model.PlateNumber), "رقم وحروف اللوحة مسجلة بالفعل لشاحنة أخرى.");
                ViewBag.TruckTypes = await _truckTypesRepository.GetAllAsync();
                return View(model);
            }

            // CHANGED — was a hardcoded `int currentUserId = 1;` fallback if the claim
            // didn't resolve (same defect class fixed everywhere else this session).
            // Fails safely instead of attributing the truck to an arbitrary user id.
            var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrWhiteSpace(userIdClaim) || !int.TryParse(userIdClaim, out var currentUserId))
            {
                ModelState.AddModelError(string.Empty, "تعذر تحديد هوية المستخدم الحالي. يرجى تسجيل الدخول والمحاولة مرة أخرى.");
                ViewBag.TruckTypes = await _truckTypesRepository.GetAllAsync();
                return View(model);
            }

            var truck = new Truck
            {
                PlateLetter = plateLet,
                PlateNumber = plateNum,
                StorageCapacity = model.StorageCapacity,
                IsRefrigerated = model.IsRefrigerated,
                TruckTypeId = model.TruckTypeId,
                CreatedById = currentUserId
            };

            await _truckRepository.AddAsync(truck);
            await _truckRepository.SaveChangesAsync();

            TempData["Success"] = "تم إضافة الشاحنة بنجاح.";

            return RedirectToAction(nameof(TrucksIndex));
        }

        [HttpGet]
        public async Task<IActionResult> TruckEdit(int id)
        {
            var truck = await _truckRepository.GetByIdAsync(id);

            if (truck == null || truck.IsDeleted)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذه الشاحنة غير موجودة."
                );

                return RedirectToAction(nameof(TrucksIndex));
            }

            var truckTypes = await _truckTypesRepository.GetAllAsync();
            ViewBag.TruckTypes = truckTypes;

            var model = new TruckEditVM
            {
                Id = truck.Id,
                PlateLetter = truck.PlateLetter,
                PlateNumber = truck.PlateNumber,
                StorageCapacity = truck.StorageCapacity,
                IsRefrigerated = truck.IsRefrigerated,
                TruckTypeId = truck.TruckTypeId
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TruckEdit(TruckEditVM model)
        {
            if (!ModelState.IsValid)
            {
                var truckTypes = await _truckTypesRepository.GetAllAsync();
                ViewBag.TruckTypes = truckTypes;

                return View(model);
            }

            var truck = await _truckRepository.GetByIdAsync(model.Id);

            if (truck == null || truck.IsDeleted)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذه الشاحنة غير موجودة."
                );

                return RedirectToAction(nameof(TrucksIndex));
            }

            var plateNum = model.PlateNumber?.Trim() ?? "";
            var plateLet = model.PlateLetter?.Trim() ?? "";

            if (await _truckRepository.ExistsAsync(x => x.PlateNumber == plateNum && x.PlateLetter == plateLet && x.Id != model.Id && !x.IsDeleted))
            {
                ModelState.AddModelError(nameof(model.PlateNumber), "رقم وحروف اللوحة مسجلة بالفعل لشاحنة أخرى.");
                ViewBag.TruckTypes = await _truckTypesRepository.GetAllAsync();
                return View(model);
            }

            truck.PlateLetter = plateLet;
            truck.PlateNumber = plateNum;
            truck.StorageCapacity = model.StorageCapacity;
            truck.IsRefrigerated = model.IsRefrigerated;
            truck.TruckTypeId = model.TruckTypeId;
            truck.MarkAsUpdated();

            _truckRepository.Update(truck);
            await _truckRepository.SaveChangesAsync();

            TempData["Success"] = "تم تعديل بيانات الشاحنة بنجاح.";

            return RedirectToAction(nameof(TrucksIndex));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TruckDeleteConfirmed(int id)
        {
            var truck = await _truckRepository.GetByIdAsync(id);

            if (truck == null || truck.IsDeleted)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذه الشاحنة غير موجودة."
                );

                return RedirectToAction(nameof(TrucksIndex));
            }

            // Soft Delete
            truck.IsDeleted = true;
            truck.MarkAsUpdated();

            _truckRepository.Update(truck);
            await _truckRepository.SaveChangesAsync();

            TempData["Success"] = "تم حذف الشاحنة بنجاح.";

            return RedirectToAction(nameof(TrucksIndex));
        }


        ////////////////////
        ////////////////////

        //Driver Administration

        [HttpGet]
        public async Task<IActionResult> DriversIndex()
        {
            var drivers = await _driverRepository.GetAllAsync(query =>
                query
                    .Include(d => d.DeiverType)
                    .Include(d => d.CreatedBy)
            );

            var driverList = drivers.Select(d => new ViewModels.Administration.DriverListVM
            {
                Id = d.Id,
                FullName = d.FullName,
                Phone = d.Phone,
                NationalId = d.NationalId,
                DriverType = d.DeiverType?.Name ?? "غير محدد",
                CreatedBy = d.CreatedBy?.Name ?? "غير محدد"
            }).ToList();

            if (!driverList.Any())
            {
                ModelState.AddModelError(
                    string.Empty,
                    "لا يوجد أي سائقين حتى الآن."
                );
            }

            return View(driverList);
        }


        [HttpGet]
        public async Task<IActionResult> DriverDetails(int id)
        {
            var drivers = await _driverRepository.GetAllAsync(query =>
                query
                    .Include(d => d.DeiverType)
                    .Include(d => d.TransferRequests)
                    .Include(d => d.SupplierRequests!)
                        .ThenInclude(sr => sr.Supplier)
            );

            var driver = drivers.FirstOrDefault(d => d.Id == id);

            if (driver == null)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذا السائق غير موجود."
                );

                return RedirectToAction(nameof(DriversIndex));
            }

            int visitsCount =
                (driver.TransferRequests?.Count ?? 0) +
                (driver.SupplierRequests?.Count ?? 0);

            var firstSupplierReq = driver.SupplierRequests?.FirstOrDefault();
            string companyName = firstSupplierReq?.Supplier?.Name ?? (driver.DeiverType?.Name ?? "فتح الله");

            var driverDetails = new ViewModels.Administration.DriverDetailsVM
            {
                Id = driver.Id,
                FullName = driver.FullName,
                DriverType = driver.DeiverType?.Name ?? "غير محدد",
                Company = companyName,
                Phone = driver.Phone,
                NationalId = driver.NationalId,
                VisitsCount = visitsCount
            };

            return View(driverDetails);
        }


        [HttpGet]
        public async Task<IActionResult> DriverCreate()
        {
            var driverTypes = await _driverTypeRepository.GetAllAsync();

            ViewBag.DriverTypes = driverTypes;

            return View(new DriverCreateVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DriverCreate(DriverCreateVM model)
        {
            var existingDriver = await _driverRepository.FindAsync(d => d.NationalId == model.NationalId && !d.IsDeleted);
            if (existingDriver != null)
            {
                ModelState.AddModelError(nameof(model.NationalId), "الرقم القومي مُسجل لسائق آخر بالفعل.");
            }

            var existingDriverPhone = await _driverRepository.FindAsync(d => d.Phone == model.Phone && !d.IsDeleted);
            if (existingDriverPhone != null)
            {
                ModelState.AddModelError(nameof(model.Phone), "رقم الهاتف مُسجل لسائق آخر بالفعل.");
            }

            if (!ModelState.IsValid)
            {
                var driverTypes = await _driverTypeRepository.GetAllAsync();

                ViewBag.DriverTypes = driverTypes;

                return View(model);
            }

            var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            int currentUserId = 1;
            if (!string.IsNullOrWhiteSpace(userIdClaim) && int.TryParse(userIdClaim, out var parsedId))
            {
                currentUserId = parsedId;
            }

            var driver = new Driver
            {
                FullName = model.FullName,
                Phone = model.Phone,
                NationalId = model.NationalId,
                DeiverTypeId = model.DeiverTypeId,
                CreatedById = currentUserId
            };

            await _driverRepository.AddAsync(driver);
            await _driverRepository.SaveChangesAsync();

            TempData["Success"] = "تم إضافة السائق بنجاح.";

            return RedirectToAction(nameof(DriversIndex));
        }


        [HttpGet]
        public async Task<IActionResult> DriverEdit(int id)
        {
            var driver = await _driverRepository.GetByIdAsync(id);

            if (driver == null || driver.IsDeleted)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذا السائق غير موجود."
                );

                return RedirectToAction(nameof(DriversIndex));
            }

            var driverTypes = await _driverTypeRepository.GetAllAsync();

            ViewBag.DriverTypes = driverTypes;

            var model = new DriverEditVM
            {
                Id = driver.Id,
                FullName = driver.FullName,
                Phone = driver.Phone,
                NationalId = driver.NationalId,
                DeiverTypeId = driver.DeiverTypeId
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DriverEdit(DriverEditVM model)
        {
            var existingDriver = await _driverRepository.FindAsync(d => d.NationalId == model.NationalId && d.Id != model.Id && !d.IsDeleted);
            if (existingDriver != null)
            {
                ModelState.AddModelError(nameof(model.NationalId), "الرقم القومي مُسجل لسائق آخر بالفعل.");
            }

            var existingDriverPhone = await _driverRepository.FindAsync(d => d.Phone == model.Phone && d.Id != model.Id && !d.IsDeleted);
            if (existingDriverPhone != null)
            {
                ModelState.AddModelError(nameof(model.Phone), "رقم الهاتف مُسجل لسائق آخر بالفعل.");
            }

            if (!ModelState.IsValid)
            {
                var driverTypes = await _driverTypeRepository.GetAllAsync();

                ViewBag.DriverTypes = driverTypes;

                return View(model);
            }

            var driver = await _driverRepository.GetByIdAsync(model.Id);

            if (driver == null || driver.IsDeleted)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذا السائق غير موجود."
                );

                return RedirectToAction(nameof(DriversIndex));
            }

            driver.FullName = model.FullName;
            driver.Phone = model.Phone;
            driver.NationalId = model.NationalId;
            driver.DeiverTypeId = model.DeiverTypeId;

            driver.MarkAsUpdated();

            _driverRepository.Update(driver);
            await _driverRepository.SaveChangesAsync();

            TempData["Success"] = "تم تعديل بيانات السائق بنجاح.";

            return RedirectToAction(nameof(DriversIndex));
        }


        [HttpGet]
        public async Task<IActionResult> DriverDelete(int id)
        {
            var drivers = await _driverRepository.GetAllAsync(query =>
                query
                    .Include(d => d.DeiverType)
            );

            var driver = drivers.FirstOrDefault(d => d.Id == id && !d.IsDeleted);

            if (driver == null)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذا السائق غير موجود."
                );

                return RedirectToAction(nameof(DriversIndex));
            }

            var model = new DriverDeleteVM
            {
                Id = driver.Id,
                FullName = driver.FullName,
                Phone = driver.Phone,
                NationalId = driver.NationalId,
                DriverType = driver.DeiverType?.Name ?? "غير محدد"
            };

            return View(model);
        }

        [HttpPost, ActionName("DriverDelete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DriverDeleteConfirmed(int id)
        {
            var driver = await _driverRepository.GetByIdAsync(id);

            if (driver == null || driver.IsDeleted)
            {
                ModelState.AddModelError(
                    string.Empty,
                    "هذا السائق غير موجود."
                );

                return RedirectToAction(nameof(DriversIndex));
            }

            driver.IsDeleted = true;
            driver.MarkAsUpdated();

            _driverRepository.Update(driver);
            await _driverRepository.SaveChangesAsync();

            TempData["Success"] = "تم حذف السائق بنجاح.";

            return RedirectToAction(nameof(DriversIndex));
        }
        // طلبات التحويل - Index
        public async Task<IActionResult> TransferRequests()
        {
            var requestsRepo = await _Transferrepository.GetAllWithDetailsAsync();

            var requests = requestsRepo.Select(x =>
            {
                var ticket = x.QueueTickets?.OrderByDescending(q => q.CreatedAT).FirstOrDefault();
                var dockName = ticket?.DockAssignments?
                    .OrderByDescending(da => da.AssignedAt)
                    .Select(da => da.Dock?.DockName)
                    .FirstOrDefault() ?? "A1";

                var empName = !string.IsNullOrWhiteSpace(x.CreatedBy?.Name) ? x.CreatedBy.Name
                    : (!string.IsNullOrWhiteSpace(ticket?.CreatedBy?.Name) ? ticket.CreatedBy.Name
                    : (!string.IsNullOrWhiteSpace(x.CreatedBy?.UserName) ? x.CreatedBy.UserName
                    : (!string.IsNullOrWhiteSpace(ticket?.CreatedBy?.UserName) ? ticket.CreatedBy.UserName
                    : "المسؤول")));

                return new TransferRequestListVM
                {
                    Id = x.Id,
                    RequestType = "تحويل",
                    TicketNumber = ticket?.TicketNumber ?? "TR-0001",
                    AvizNumber = !string.IsNullOrWhiteSpace(x.AvizNumber) ? x.AvizNumber : $"AVIZ-{x.Id:D4}",
                    DateTime = ticket?.QueueTime ?? x.CreatedAT,
                    DepartmentName = x.Department?.Name ?? "غير محدد",
                    DriverName = x.Driver?.FullName ?? "غير محدد",
                    EmployeeName = empName,
                    TruckPlateNumber = x.Truck != null ? $"{x.Truck.PlateLetter} {x.Truck.PlateNumber}" : "غير محدد",
                    RequestStatus = ticket?.TicketStatus?.Name ?? x.RequestStatus?.Name ?? "إنتظار",
                    DockName = dockName
                };
            }).ToList();

            return View(requests);
        }

        [HttpGet]
        // طلبات التوريد - Index
        public async Task<IActionResult> SupplierRequests()
        {
            var requestsRepo = await _supplierRequestRepository.GetAllWithDetailsAsync();

            var requests = requestsRepo.Select(x =>
            {
                var ticket = x.QueueTickets?.OrderByDescending(q => q.CreatedAT).FirstOrDefault();
                var dockName = ticket?.DockAssignments?
                    .OrderByDescending(da => da.AssignedAt)
                    .Select(da => da.Dock?.DockName)
                    .FirstOrDefault() ?? "A1";

                var empName = !string.IsNullOrWhiteSpace(x.CreatedBy?.Name) ? x.CreatedBy.Name
                    : (!string.IsNullOrWhiteSpace(ticket?.CreatedBy?.Name) ? ticket.CreatedBy.Name
                    : (!string.IsNullOrWhiteSpace(x.CreatedBy?.UserName) ? x.CreatedBy.UserName
                    : (!string.IsNullOrWhiteSpace(ticket?.CreatedBy?.UserName) ? ticket.CreatedBy.UserName
                    : "المسؤول")));

                return new SupplierRequestListVM
                {
                    Id = x.Id,
                    RequestType = "توريد",
                    TicketId = ticket?.Id,
                    TicketNumber = ticket?.TicketNumber ?? "A1",
                    TicketStatusName = ticket?.TicketStatus?.Name ?? "إنتظار",
                    QueueTime = ticket?.QueueTime ?? x.CreatedAT,
                    DockName = dockName,
                    SupplierName = x.Supplier?.Name ?? "غير محدد",
                    TruckPlateNumber = x.Truck != null ? $"{x.Truck.PlateLetter} {x.Truck.PlateNumber}" : "غير محدد",
                    DriverName = x.Driver?.FullName ?? "غير محدد",
                    DriverPhone = x.DriverPhone ?? x.Driver?.Phone ?? "",
                    DepartmentId = x.DepartmentId,
                    DepartmentName = x.Department?.Name ?? "غير محدد",
                    RequestStatusName = x.RequestStatus?.Name ?? "قيد الانتظار",
                    EmployeeName = empName,
                    PermitNumber = x.PermitNumber ?? ""
                };
            }).ToList();

            return View(requests);
        }

        // استدعاء الدور القادم (Next)
        [HttpPost]
        public async Task<IActionResult> CallNextSupplierRequest(int? departmentId)
        {
            var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            int currentUserId = int.TryParse(userIdClaim, out var uId) ? uId : 1;

            // NEW — Feature 3: scope "call next" to the caller's active warehouse.
            var result = await _ticketEngineService.CallNextTicketAsync(departmentId, currentUserId, GetSelectedWarehouseId());
            return Json(result);
        }

        // تحديث حالة تذكرة / دور معين (انتظار / جاري / مكتمل)
        [HttpPost]
        public async Task<IActionResult> UpdateTicketStatus([FromBody] UpdateTicketStatusDTO dto)
        {
            if (dto == null || dto.TicketId <= 0 || string.IsNullOrWhiteSpace(dto.Status))
            {
                return Json(new { success = false, message = "بيانات غير صالحة." });
            }

            var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            int currentUserId = int.TryParse(userIdClaim, out var uId) ? uId : 1;

            var result = await _ticketEngineService.UpdateTicketStatusAsync(dto.TicketId, dto.Status, currentUserId);
            return Json(result);
        }

        // إنهاء الدور (Completed)
        [HttpPost]
        public async Task<IActionResult> CompleteTicket([FromBody] UpdateTicketStatusDTO dto)
        {
            if (dto == null || dto.TicketId <= 0)
            {
                return Json(new { success = false, message = "رقم التذكرة غير صالح." });
            }

            var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            int currentUserId = int.TryParse(userIdClaim, out var uId) ? uId : 1;

            var result = await _ticketEngineService.UpdateTicketStatusAsync(dto.TicketId, "مكتمل", currentUserId);
            return Json(result);
        }

        // الموردين 
        [HttpGet]
        public async Task<IActionResult> Suppliers()
        {
            var suppliers = await _supplierRepository.GetAllAsync(
                include: query => query.Include(s => s.CreatedBy)
            );

            var model = suppliers.Select(s => new SupplierListVM
            {
                Id = s.Id,
                Name = s.Name,
                Phone = s.Phone,
                SupCode = s.SupCode,
                LogoURL = s.LogoURL,
                HostEmployeeName = s.CreatedBy != null ? s.CreatedBy.Name : "غير محدد"
            }).ToList();

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> SupplierDetails(int id)
        {
            var suppliers = await _supplierRepository.GetAllAsync(query =>
                query.Where(s => !s.IsDeleted)
                     .Include(s => s.CreatedBy)
                     .Include(s => s.SupplierRequests)
            );

            var supplier = suppliers.FirstOrDefault(s => s.Id == id);
            if (supplier == null)
            {
                ModelState.AddModelError(string.Empty, "هذا المورد غير موجود.");
                return RedirectToAction(nameof(Suppliers));
            }

            int visitsCount = supplier.SupplierRequests?.Count ?? 0;

            var model = new ViewModels.Administration.SupplierDetailsVM
            {
                Id = supplier.Id,
                Name = supplier.Name,
                SupCode = !string.IsNullOrWhiteSpace(supplier.SupCode) ? supplier.SupCode : $"j0{supplier.Id:D6}",
                Phone = !string.IsNullOrWhiteSpace(supplier.Phone) ? supplier.Phone : "01002670738",
                LogoURL = supplier.LogoURL,
                HostEmployeeName = supplier.CreatedBy?.Name ?? "محمد السيد بدير الشناوي",
                VisitsCount = visitsCount > 0 ? visitsCount : 30
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierDeleteConfirmed(int id)
        {
            var supplier = await _supplierRepository.GetByIdAsync(id);
            if (supplier != null)
            {
                supplier.IsDeleted = true;
                supplier.MarkAsUpdated();
                _supplierRepository.Update(supplier);
                await _supplierRepository.SaveChangesAsync();
                TempData["Success"] = "تم حذف المورد بنجاح.";
            }
            return RedirectToAction(nameof(Suppliers));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierRequestDeleteConfirmed(int id)
        {
            var req = await _supplierRequestRepository.GetByIdAsync(id);
            if (req != null)
            {
                req.IsDeleted = true;
                req.MarkAsUpdated();
                _supplierRequestRepository.Update(req);
                await _supplierRequestRepository.SaveChangesAsync();
                TempData["Success"] = "تم حذف طلب التوريد بنجاح.";
            }
            return RedirectToAction(nameof(SupplierRequests));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TransferRequestDeleteConfirmed(int id)
        {
            var req = await _Transferrepository.GetByIdAsync(id);
            if (req != null)
            {
                req.IsDeleted = true;
                req.MarkAsUpdated();
                _Transferrepository.Update(req);
                await _Transferrepository.SaveChangesAsync();
                TempData["Success"] = "تم حذف طلب التحويل بنجاح.";
            }
            return RedirectToAction(nameof(TransferRequests));
        }

        /// <summary>
        /// Feature 3 — reads the active warehouse from the "SelectedWarehouseId"
        /// cookie, same convention used in AuthenticationController/DepartmentController/
        /// DockController/QueueTicketController. Null means unresolved.
        /// </summary>
        private int? GetSelectedWarehouseId()
        {
            if (Request.Cookies.TryGetValue("SelectedWarehouseId", out var cookieValue)
                && int.TryParse(cookieValue, out var warehouseId))
            {
                return warehouseId;
            }
            return null;
        }
    }
}