using Rassef.Filters;

namespace Rassef
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);



            builder.Services.AddControllersWithViews(options =>
            {
                options.Filters.Add<NoCacheAttribute>();
            });

            builder.Services.AddDependcyInjection(builder.Configuration);
            builder.Host.UseSerilog();
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.AddMiddleWares();

            // Seed Admin User, Roles and Permissions
            await Rassef.Data.DbInitializer.SeedAsync(app.Services);

            await app.RunAsync();
        }
    }
}